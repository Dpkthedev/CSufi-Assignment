package com.example.assignment.database;

import android.content.Context;
import android.util.Log;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.assignment.R;
import com.example.assignment.database.Entity;
import com.example.assignment.database.MainRoomDatabase;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class MainRepository {

    public void test()
    {
        Log.d("test","from MainRepository");
    }
    private MutableLiveData<Boolean> _databaseInsertionLiveData= new MutableLiveData<>();
    public LiveData<Boolean> databaseInsertionLiveData= _databaseInsertionLiveData;
    public LiveData<Boolean> readJsonAndSaveInDB(Context context)
    {
        _databaseInsertionLiveData.setValue(false);
        InputStream is = context.getResources().openRawResource(R.raw.response);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
            is.close();
        }

        catch(Exception ex) {
            _databaseInsertionLiveData.setValue(false);
        }
        String jsonString = writer.toString();
        Gson gson = new Gson();
        Entity[] studentData =  gson.fromJson(jsonString,Entity[].class);
        List<Entity> studentDataList = Arrays.asList(studentData);
        new Thread(new Runnable() {
            @Override
            public void run() {
                insertStudentDataInDB(studentDataList, context);
            }
        }).start();

        return _databaseInsertionLiveData;
    }


    private void insertStudentDataInDB(List<Entity> data, Context context)
    {
        for(Entity student:data)
        {
            Log.d("InsertStudentDataInDB", student.firstName);
            MainRoomDatabase.getRoomDatabase(context).getDao().insertClassData(student);
        }
        _databaseInsertionLiveData.postValue(true);
    }

    public  LiveData<HashMap<String, List<Entity>>> getClassesFromDB(Context context)
    {
        Log.d("getClassesFromDB","started");
        HashMap<String,List<Entity>> classStudentMap= new HashMap<>();
        MutableLiveData<HashMap<String,List<Entity>>> studentMapLiveData = new MutableLiveData<>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                HashSet<String> classes=  new HashSet<>(MainRoomDatabase.getRoomDatabase(context).getDao().getClasses());

                for (String classname:classes)
                {
                    classStudentMap.put(classname,MainRoomDatabase.getRoomDatabase(context).getDao().getStudentsByClass(classname));

                }
                studentMapLiveData.postValue(classStudentMap);
                Log.d("getClassesFromDB","Map size: "+ classStudentMap.size()+"");
            }
        }).start();
        return  studentMapLiveData;
    }

    public void deleteStudentFromClass(Context context, Entity studentToDelete )
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                MainRoomDatabase.getRoomDatabase(context).getDao().deleteStudentFromClass(studentToDelete);
            }
        }).start();
    }


}
