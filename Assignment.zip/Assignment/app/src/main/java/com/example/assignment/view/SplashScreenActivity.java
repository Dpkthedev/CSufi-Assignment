package com.example.assignment.view;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.assignment.database.MainRepository;
import com.example.assignment.MainViewModelFactory;
import com.example.assignment.R;
import com.example.assignment.database.Entity;
import com.example.assignment.viewmodel.MainViewModel;

import java.util.HashMap;
import java.util.List;

public class SplashScreenActivity extends AppCompatActivity {

    private  HashMap<String, List<Entity>> classList= new HashMap<String, List<Entity>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        MainViewModelFactory viewModelFactory= new MainViewModelFactory(new MainRepository());
        MainViewModel viewModel= new ViewModelProvider(this,viewModelFactory).get(MainViewModel.class);
        ProgressBar progressBar = findViewById(R.id.progress);

        viewModel.getStudentDetailsFromDB(getApplicationContext()).observe(this, new Observer<HashMap<String, List<Entity>>>() {
            @Override
            public void onChanged(HashMap<String, List<Entity>> stringListHashMap) {
                classList= stringListHashMap;
                //if data do not present in db,  parse json and save
                if(classList== null || classList.size()==0)
                {
                    viewModel.readRawJsonAndSaveInDB(getApplicationContext()).observe(SplashScreenActivity.this, new Observer<Boolean>() {
                        @Override
                        public void onChanged(Boolean isSuccess) {
                            if(isSuccess)
                            {
                                progressBar.setVisibility(View.GONE);
                                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });
                }
                else
                {
                    progressBar.setVisibility(View.GONE);
                    Intent intent = new Intent(SplashScreenActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });


    }
}