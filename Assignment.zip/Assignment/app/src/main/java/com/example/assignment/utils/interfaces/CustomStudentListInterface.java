package com.example.assignment.utils.interfaces;

import com.example.assignment.database.Entity;

public interface CustomStudentListInterface {

     void deleteItem(Entity itemToDelete);
}
