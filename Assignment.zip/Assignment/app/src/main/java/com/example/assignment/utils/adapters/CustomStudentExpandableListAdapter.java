package com.example.assignment.utils.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import com.example.assignment.R;
import com.example.assignment.database.Entity;
import com.example.assignment.utils.interfaces.CustomStudentListInterface;
import java.util.HashMap;
import java.util.List;

public class CustomStudentExpandableListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> expandableTitleList;
    private HashMap<String, List<Entity>> expandableDetailList;
    private CustomStudentListInterface studentListInterface;

    public CustomStudentExpandableListAdapter(Context context, List<String> expandableTitleList, HashMap<String, List<Entity>> expandableDetailList)
    {
        this.context= context;
        this.expandableTitleList=expandableTitleList;
        this.expandableDetailList = expandableDetailList;
        studentListInterface= (CustomStudentListInterface)context;
    }
    @Override
    public int getGroupCount() {
        Log.d("Adapter","getGroupCount: "+ expandableTitleList.size() );
        return expandableTitleList.size();
    }

    @Override
    public int getChildrenCount(int pos) {
        Log.d("Adapter","getChildrenCount: "+ this.expandableDetailList.get(this.expandableTitleList.get(pos)).size() );
        return this.expandableDetailList.get(this.expandableTitleList.get(pos)).size();
    }

    @Override
    public Object getGroup(int i) {
        return this.expandableTitleList.get(i);
    }

    @Override
    public Object getChild(int listPosition, int expandedPosition) {
        return this.expandableDetailList.get(this.expandableTitleList.get(listPosition)).get(expandedPosition);
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public long getChildId(int i, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int position, boolean iSExpanded, View convertView, ViewGroup viewGroup) {
        //check for re-using view
        if(convertView== null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.student_el_header_item, null);
        }

        TextView nameTv= convertView.findViewById(R.id.name_tv);
        TextView rollNoTv= convertView.findViewById(R.id.roll_no_tv);
        nameTv.setTypeface(null,Typeface.BOLD);
        rollNoTv.setTypeface(null, Typeface.BOLD);
        Entity item = expandableDetailList.get(expandableTitleList.get(position)).get(0);
        nameTv.setText(item.firstName+ " "+item.lastName);
        rollNoTv.setText(item.rollNumber);
        return convertView;
    }

    @Override
    public View getChildView(int listposition, int expandedPosition, boolean b, View convertView, ViewGroup viewGroup) {
        ViewHolderItem tag= new ViewHolderItem();
        tag.groupPosition= listposition;
        tag.childPosition=expandedPosition;
        if(convertView== null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.student_el_child_item, null);
        }
        Entity item = expandableDetailList.get(expandableTitleList.get(listposition)).get(expandedPosition);
        TextView rollNoTv= convertView.findViewById(R.id.el_child_roll_no_tv);
        Spanned text= Html.fromHtml("<b>" + context.getResources().getString(R.string.roll_number_text) + "</b>" +item.rollNumber,Html.FROM_HTML_MODE_COMPACT);
        rollNoTv.setText(text);
        ImageButton deleteBtn= convertView.findViewById(R.id.child_delete_btn);
        deleteBtn.setTag(tag);
        Log.d("getChildView","marks " + item.marks);
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                studentListInterface.deleteItem(item);
            }
        });
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    /**
     * ViewHolger class to set tag
     */
    class ViewHolderItem
    {
        public int groupPosition;
        public int childPosition;
    }

    /**
     *updates data
     * @param titleList class name
     * @param studentDataMap student list
     */
    public void updateData(List<String> titleList,HashMap<String, List<Entity>> studentDataMap)
    {
        this.expandableTitleList=titleList;
        this.expandableDetailList= studentDataMap;
        notifyDataSetChanged();
    }

}
