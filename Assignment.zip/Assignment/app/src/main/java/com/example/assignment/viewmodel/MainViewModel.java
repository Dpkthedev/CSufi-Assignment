package com.example.assignment.viewmodel;

import android.content.Context;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.assignment.database.MainRepository;
import com.example.assignment.database.Entity;
import java.util.HashMap;
import java.util.List;

public class MainViewModel extends ViewModel {

    private MainRepository repository;
    private MutableLiveData<String> _resultLiveData= new MutableLiveData<>();
    public LiveData<String> resultLiveData= _resultLiveData;
    public MainViewModel( MainRepository repository)
    {
        this.repository= repository;
    }

    public LiveData<HashMap<String, List<Entity>>> getStudentDetailsFromDB(Context context)
    {
        return repository.getClassesFromDB(context);
    }

    public LiveData<Boolean> readRawJsonAndSaveInDB(Context context)
    {
        return repository.readJsonAndSaveInDB(context);
    }

    public void DeleteStudent(Entity student, Context context)
    {
         repository.deleteStudentFromClass( context, student);
    }
}
