package com.example.assignment.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public static String getDate()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
        String currentDateTime = sdf.format(new Date());
        return currentDateTime;
    }

    public static String getTime()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        String currentTime = sdf.format(new Date());
        return currentTime;
    }


}
