package com.example.assignment.database;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.HashMap;
import java.util.List;

@androidx.room.Dao
public interface Dao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertClassData(Entity entity);
    @Query("SELECT class FROM StudentData")
    public List<String> getClasses();

    @Query("SELECT * FROM StudentData WHERE class IS :className ORDER BY marks DESC ")
    public List<Entity> getStudentsByClass(String className);
    @Delete
    public void deleteStudentFromClass(Entity student);
//    @Query("SELECT * FROM StudentData GROUP BY class")
//    public HashMap<String, List<Entity>> getAllStudents();
}
