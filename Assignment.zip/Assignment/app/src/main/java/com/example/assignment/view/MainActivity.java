package com.example.assignment.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ExpandableListView;

import com.example.assignment.database.MainRepository;
import com.example.assignment.MainViewModelFactory;
import com.example.assignment.R;
import com.example.assignment.database.Entity;
import com.example.assignment.utils.Utils;
import com.example.assignment.utils.adapters.CustomStudentExpandableListAdapter;
import com.example.assignment.utils.interfaces.CustomStudentListInterface;
import com.example.assignment.viewmodel.MainViewModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CustomStudentListInterface {

    MainViewModel viewModel;
    MainViewModelFactory viewModelFactory;
    ExpandableListView studentExpListView;
    CustomStudentExpandableListAdapter studentExpListAdapter;
    HashMap<String, List<Entity>> studentListHashMap= new HashMap<String, List<Entity>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Set date time in ActionBar
        Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolBar);
        getSupportActionBar().setTitle(Utils.getDate());
        getSupportActionBar().setSubtitle(Utils.getTime());
        studentExpListView= (ExpandableListView) findViewById(R.id.student_list_elv);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels;
        studentExpListView.setIndicatorBounds(width - getPixelsForDPs(50), width - getPixelsForDPs(10));
        viewModelFactory= new MainViewModelFactory(new MainRepository());
        viewModel= new ViewModelProvider(this,viewModelFactory).get(MainViewModel.class);
        viewModel.getStudentDetailsFromDB(getApplicationContext()).observe(this, new Observer<HashMap<String, List<Entity>>>() {
            @Override
            public void onChanged(HashMap<String, List<Entity>> stringListHashMap) {
                if(stringListHashMap!= null && stringListHashMap.size()>0)
                {
                   studentListHashMap= stringListHashMap;
                   studentExpListAdapter.updateData(new ArrayList<String>(studentListHashMap.keySet()),studentListHashMap);
                }
            }
        });
        studentExpListAdapter = new CustomStudentExpandableListAdapter(this,new ArrayList<String>(studentListHashMap.keySet()),studentListHashMap);
        studentExpListView.setAdapter(studentExpListAdapter);
    }



    private int getPixelsForDPs(float pixels)
    {
        // Get the screen's density scale
        final float scale = getResources().getDisplayMetrics().density;
        // Convert the dps to pixels, based on density scale
        return (int) (pixels * scale + 0.5f);
    }

    @Override
    public void deleteItem(Entity itemToDelete) {
        viewModel.DeleteStudent(itemToDelete, getApplicationContext());
        RemoveItemFromHashMap(itemToDelete);

    }

    private void RemoveItemFromHashMap( Entity item)
    {
        List<Entity> tempList= studentListHashMap.get(item.className);
        tempList.remove(item);
        studentListHashMap.put(item.className,tempList);
        studentExpListAdapter.notifyDataSetChanged();
    }


}