package com.example.assignment.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Entity.class}, version = 1)
public abstract class MainRoomDatabase extends RoomDatabase {

    private static MainRoomDatabase instance;

    public static MainRoomDatabase getRoomDatabase(Context context)
    {
        if(instance == null)
        {
            instance= Room.databaseBuilder(context.getApplicationContext(),
                    MainRoomDatabase.class, "studentsDB").build();
        }
        return instance;
    }

    public abstract Dao getDao();

}
