package com.example.assignment.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

@androidx.room.Entity(tableName = "StudentData")
public class Entity {


    @ColumnInfo (name = "marks")
    public int marks;
    @PrimaryKey
    @NonNull
    @ColumnInfo (name = "roll_number")
    @SerializedName("roll_number")
    public String rollNumber;
    @ColumnInfo (name = "class")
    @SerializedName("class")
    public String className;
    @ColumnInfo (name = "first_name")
    @SerializedName("first_name")
    public String firstName;
    @ColumnInfo (name = "last_name")
    @SerializedName("last_name")
    public String lastName;
}
