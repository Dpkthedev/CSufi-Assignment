package com.example.assignment;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.assignment.database.MainRepository;
import com.example.assignment.viewmodel.MainViewModel;

public class MainViewModelFactory implements ViewModelProvider.Factory {

    private MainRepository repository;
    public MainViewModelFactory(MainRepository repository)
    {
        this.repository= repository;
    }


    @Override
    public <T extends ViewModel> T create( Class<T> modelClass) {


        if (modelClass.isAssignableFrom(MainViewModel.class))
        {
            return (T)new MainViewModel(repository);
        }
        throw new IllegalArgumentException("Unknown ViewModel class");


    }
}
